import React, { useState, useEffect } from 'react';
import { Gauge, Thermometer, Fuel, Zap, AlertTriangle, Navigation, Settings, Activity } from 'lucide-react';

const Dashboard = () => {
  const [metrics, setMetrics] = useState({
    speed: 0,
    rpm: 800,
    fuel: 85,
    engineTemp: 90,
    oilPressure: 45,
    batteryVoltage: 12.6,
    coolantTemp: 85,
    airIntakeTemp: 25,
    boost: 0,
    gear: 'P',
    odometer: 87432,
    tripDistance: 127.8,
    avgFuelEconomy: 8.5,
    instantFuelEconomy: 7.2
  });

  const [warnings, setWarnings] = useState([]);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isRunning, setIsRunning] = useState(false);

  // mapping for Tailwind-safe classes
  const colorMap = {
    blue: 'text-blue-500',
    red: 'text-red-500',
    green: 'text-green-500',
    orange: 'text-orange-500',
    purple: 'text-purple-500',
    cyan: 'text-cyan-500',
    yellow: 'text-yellow-500'
  };

  // Simulate real-time data updates
  useEffect(() => {
    let interval = null;
    if (!isRunning) return;

    interval = setInterval(() => {
      setMetrics(prev => {
        const speedChange = (Math.random() - 0.4) * 8; // slight bias to accelerate when running
        const newSpeed = Math.max(0, Math.min(200, prev.speed + speedChange));
        const newRpm = Math.max(700, Math.min(7000, prev.rpm + (newSpeed - prev.speed) * 20 + (Math.random() - 0.5) * 200));
        const distanceInc = (newSpeed / 3600) * 0.5; // km per tick roughly depending on interval
        const newOdometer = +(prev.odometer + distanceInc).toFixed(3);
        const newTrip = +(prev.tripDistance + distanceInc).toFixed(3);

        const gear = determineGear(newSpeed);

        return {
          ...prev,
          speed: newSpeed,
          rpm: newRpm,
          fuel: Math.max(0, prev.fuel - Math.random() * 0.02),
          engineTemp: 85 + Math.random() * 12,
          oilPressure: 35 + Math.random() * 15,
          batteryVoltage: 12.3 + Math.random() * 0.6,
          coolantTemp: 80 + Math.random() * 8,
          airIntakeTemp: 20 + Math.random() * 8,
          boost: newSpeed > 50 ? Math.random() * 15 : 0,
          instantFuelEconomy: 4 + Math.random() * 10,
          odometer: newOdometer,
          tripDistance: newTrip,
          gear
        };
      });
    }, 500); // 500ms for smoother CPU usage

    return () => clearInterval(interval);
  }, [isRunning]);

  // simple gear determination for automatic gearbox feel
  function determineGear(speed) {
    if (speed < 2) return 'P';
    if (speed < 10) return '1';
    if (speed < 30) return '2';
    if (speed < 60) return '3';
    if (speed < 100) return '4';
    if (speed < 150) return '5';
    return '6';
  }

  // Monitor for warnings
  useEffect(() => {
    const newWarnings = [];
    if (metrics.engineTemp > 100) newWarnings.push('High Engine Temperature');
    if (metrics.fuel < 20) newWarnings.push('Low Fuel');
    if (metrics.oilPressure < 30) newWarnings.push('Low Oil Pressure');
    if (metrics.batteryVoltage < 12.0) newWarnings.push('Low Battery');
    setWarnings(newWarnings);
  }, [metrics]);

  const CircularGauge = ({ value, max, label, unit, color = 'blue', size = 'lg' }) => {
    const percentage = (value / max) * 100;
    const circumference = 2 * Math.PI * 45;
    const strokeDasharray = `${(percentage / 100) * circumference} ${circumference}`;

    const sizeClass = size === 'lg' ? 'w-32 h-32' : 'w-20 h-20';
    const textSize = size === 'lg' ? 'text-2xl' : 'text-base';

    return (
      <div className={`relative ${sizeClass} flex flex-col items-center`}>
        <svg className="transform -rotate-90 w-full h-full">
          <circle
            cx="50%"
            cy="50%"
            r="45%"
            fill="none"
            stroke="currentColor"
            strokeWidth="4"
            className="text-gray-700 opacity-30"
          />
          <circle
            cx="50%"
            cy="50%"
            r="45%"
            fill="none"
            stroke="currentColor"
            strokeWidth="4"
            strokeDasharray={strokeDasharray}
            strokeLinecap="round"
            className={`${colorMap[color] || colorMap.blue} transition-all duration-500`}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className={`${textSize} font-bold text-white`}>
            {typeof value === 'number' ? (value < 10 ? value.toFixed(1) : Math.round(value)) : value}
          </div>
          <div className="text-xs text-gray-400">{unit}</div>
        </div>
        <div className="text-xs text-gray-300 mt-1 text-center">{label}</div>
      </div>
    );
  };

  const LinearGauge = ({ value, max, label, unit, color = 'green' }) => {
    const percentage = (value / max) * 100;

    return (
      <div className="flex flex-col space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-300">{label}</span>
          <span className="text-white font-semibold">{typeof value === 'number' ? value.toFixed(1) : value} {unit}</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-3 overflow-hidden">
          <div 
            className={`h-full ${colorMap[color] ? colorMap[color].replace('text','bg').replace('-500','-600') : 'bg-green-600'} transition-all duration-500 rounded-full`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    );
  };

  return (
    <div className={`min-h-screen p-4 transition-all duration-500 ${isDarkMode ? 'bg-gray-900' : 'bg-gray-100'}`}>
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-4">
          <Activity className="text-blue-500 w-8 h-8" />
          <h1 className="text-2xl font-bold text-white">Performance Dashboard</h1>
          {warnings.length > 0 && (
            <div className="flex items-center space-x-2 bg-red-900 px-3 py-1 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <span className="text-red-300 text-sm">{warnings.length} Warning{warnings.length > 1 ? 's' : ''}</span>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              isRunning 
                ? 'bg-red-600 hover:bg-red-700 text-white' 
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
          >
            {isRunning ? 'Stop Engine' : 'Start Engine'}
          </button>
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white transition-colors"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Gauges */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gray-800 rounded-2xl p-6 shadow-2xl">
          <CircularGauge 
            value={metrics.speed} 
            max={200} 
            label="Speed" 
            unit="km/h" 
            color="blue"
            size="lg"
          />
        </div>

        <div className="bg-gray-800 rounded-2xl p-6 shadow-2xl">
          <CircularGauge 
            value={metrics.rpm} 
            max={8000} 
            label="Engine RPM" 
            unit="RPM" 
            color="red"
            size="lg"
          />
        </div>

        <div className="bg-gray-800 rounded-2xl p-6 shadow-2xl">
          <CircularGauge 
            value={metrics.fuel} 
            max={100} 
            label="Fuel Level" 
            unit="%" 
            color={metrics.fuel > 25 ? 'green' : 'red'}
            size="lg"
          />
        </div>

        <div className="bg-gray-800 rounded-2xl p-6 shadow-2xl">
          <CircularGauge 
            value={metrics.engineTemp} 
            max={120} 
            label="Engine Temp" 
            unit="°C" 
            color={metrics.engineTemp > 100 ? 'red' : 'orange'}
            size="lg"
          />
        </div>
      </div>

      {/* Secondary Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Performance Metrics */}
        <div className="bg-gray-800 rounded-2xl p-6 shadow-2xl">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Zap className="w-5 h-5 mr-2 text-yellow-500" />
            Performance
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <CircularGauge 
              value={metrics.boost} 
              max={20} 
              label="Boost" 
              unit="PSI" 
              color="purple"
              size="sm"
            />
            <CircularGauge 
              value={metrics.oilPressure} 
              max={80} 
              label="Oil Pressure" 
              unit="PSI" 
              color="blue"
              size="sm"
            />
          </div>
        </div>

        {/* System Status */}
        <div className="bg-gray-800 rounded-2xl p-6 shadow-2xl">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Settings className="w-5 h-5 mr-2 text-green-500" />
            System Status
          </h3>
          <div className="space-y-4">
            <LinearGauge 
              value={metrics.batteryVoltage} 
              max={14} 
              label="Battery Voltage" 
              unit="V" 
              color="green"
            />
            <LinearGauge 
              value={metrics.coolantTemp} 
              max={110} 
              label="Coolant Temp" 
              unit="°C" 
              color="blue"
            />
            <LinearGauge 
              value={metrics.airIntakeTemp} 
              max={50} 
              label="Air Intake Temp" 
              unit="°C" 
              color="cyan"
            />
          </div>
        </div>

        {/* Trip Information */}
        <div className="bg-gray-800 rounded-2xl p-6 shadow-2xl">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Navigation className="w-5 h-5 mr-2 text-blue-500" />
            Trip Info
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="text-gray-300">Current Gear</span>
              <span className="text-2xl font-bold text-blue-400">{metrics.gear}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Odometer</span>
              <span className="text-white font-semibold">{Number(metrics.odometer).toLocaleString()} km</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Trip Distance</span>
              <span className="text-white font-semibold">{Number(metrics.tripDistance).toFixed(2)} km</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Avg Fuel Economy</span>
              <span className="text-green-400 font-semibold">{metrics.avgFuelEconomy} L/100km</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Instant Economy</span>
              <span className="text-blue-400 font-semibold">{metrics.instantFuelEconomy.toFixed(1)} L/100km</span>
            </div>
          </div>
        </div>
      </div>

      {/* Warning Panel */}
      {warnings.length > 0 && (
        <div className="bg-red-900 border border-red-700 rounded-2xl p-4 shadow-2xl">
          <h3 className="text-lg font-semibold text-red-300 mb-3 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            System Warnings
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {warnings.map((warning, index) => (
              <div key={index} className="bg-red-800 px-3 py-2 rounded-lg text-red-200 text-sm">
                {warning}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Status Bar */}
      <div className="fixed bottom-4 left-4 right-4 bg-gray-800 rounded-lg p-3 shadow-2xl">
        <div className="flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <div className={`w-3 h-3 rounded-full ${isRunning ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
            <span className="text-gray-300">Engine: {isRunning ? 'Running' : 'Stopped'}</span>
          </div>
          <div className="text-gray-400">
            {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
